class RideModel {
  final String id;
  final String customerId;
  final String? driverId;
  final String rideType;
  final Map<String, dynamic> pickup;
  final Map<String, dynamic> destination;
  final double distanceKm;
  final double totalFare;
  final String otp;
  final String status;
  final bool isScheduled;
  final bool agreedToTollPolicy;

  RideModel({
    required this.id,
    required this.customerId,
    this.driverId,
    required this.rideType,
    required this.pickup,
    required this.destination,
    required this.distanceKm,
    required this.totalFare,
    required this.otp,
    required this.status,
    this.isScheduled = false,
    required this.agreedToTollPolicy,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'driverId': driverId,
      'rideType': rideType,
      'pickup': pickup,
      'destination': destination,
      'distanceKm': distanceKm,
      'totalFare': totalFare,
      'otp': otp,
      'status': status,
      'isScheduled': isScheduled,
      'agreedToTollPolicy': agreedToTollPolicy,
      'createdAt': DateTime.now().toIso8601String(),
    };
  }
}
