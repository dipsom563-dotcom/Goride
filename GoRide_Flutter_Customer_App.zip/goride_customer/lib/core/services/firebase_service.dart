import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../data/models/ride_model.dart';

class FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference get users => _firestore.collection('users');
  CollectionReference get rides => _firestore.collection('rides');
  CollectionReference get fareSettings => _firestore.collection('fare_settings');

  Future<UserCredential> loginWithPhone(String phone, String password) async {
    final email = '${phone.replaceAll(RegExp(r'[^0-9]'), '')}@goride.customer';
    return await _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<UserCredential> registerCustomer(String name, String phone, String password) async {
    final email = '${phone.replaceAll(RegExp(r'[^0-9]'), '')}@goride.customer';
    final creds = await _auth.createUserWithEmailAndPassword(email: email, password: password);
    await users.doc(creds.user!.uid).set({
      'uid': creds.user!.uid,
      'fullName': name,
      'phoneNumber': phone,
      'createdAt': FieldValue.serverTimestamp(),
    });
    return creds;
  }

  Future<void> createBooking(RideModel ride) async {
    await rides.doc(ride.id).set(ride.toMap());
  }
}
