import 'dart:math';

enum RideType { bike, auto, mini, sedan, suv }

class FareSettings {
  final Map<RideType, double> baseFare;
  final Map<RideType, double> customerPerKm;
  final Map<RideType, double> driverPerKm;
  final Map<RideType, double> minimumFare;
  final double waitingChargePerMin;
  final double nightChargeMultiplier;
  final double peakHourMultiplier;

  const FareSettings({
    required this.baseFare,
    required this.customerPerKm,
    required this.driverPerKm,
    required this.minimumFare,
    required this.waitingChargePerMin,
    required this.nightChargeMultiplier,
    required this.peakHourMultiplier,
  });

  static const defaultSettings = FareSettings(
    baseFare: {
      RideType.bike: 25.0,
      RideType.auto: 40.0,
      RideType.mini: 60.0,
      RideType.sedan: 80.0,
      RideType.suv: 120.0,
    },
    customerPerKm: {
      RideType.bike: 8.0,
      RideType.auto: 12.0,
      RideType.mini: 15.0,
      RideType.sedan: 19.0,
      RideType.suv: 24.0,
    },
    driverPerKm: {
      RideType.bike: 6.5,
      RideType.auto: 10.0,
      RideType.mini: 12.5,
      RideType.sedan: 16.0,
      RideType.suv: 20.0,
    },
    minimumFare: {
      RideType.bike: 35.0,
      RideType.auto: 60.0,
      RideType.mini: 90.0,
      RideType.sedan: 130.0,
      RideType.suv: 180.0,
    },
    waitingChargePerMin: 2.5,
    nightChargeMultiplier: 1.25,
    peakHourMultiplier: 1.35,
  );
}

class FareBreakdown {
  final double baseFare;
  final double distanceFare;
  final double nightCharge;
  final double peakCharge;
  final double waitingCharge;
  final double totalCustomerFare;
  final double driverEarnings;
  final double adminCommission;

  FareBreakdown({
    required this.baseFare,
    required this.distanceFare,
    required this.nightCharge,
    required this.peakCharge,
    required this.waitingCharge,
    required this.totalCustomerFare,
    required this.driverEarnings,
    required this.adminCommission,
  });
}

class FareCalculator {
  static FareBreakdown calculate({
    required RideType rideType,
    required double distanceKm,
    double waitingMinutes = 0,
    FareSettings settings = FareSettings.defaultSettings,
  }) {
    final now = DateTime.now();
    final hour = now.hour;
    final isNight = hour >= 22 || hour < 6;
    final isPeak = !isNight && ((hour >= 8 && hour <= 10) || (hour >= 17 && hour <= 20));

    final base = settings.baseFare[rideType]!;
    final custRate = settings.customerPerKm[rideType]!;
    final drivRate = settings.driverPerKm[rideType]!;
    final minFare = settings.minimumFare[rideType]!;

    double distFare = distanceKm * custRate;
    double night = isNight ? (base + distFare) * (settings.nightChargeMultiplier - 1) : 0;
    double peak = isPeak ? (base + distFare) * (settings.peakHourMultiplier - 1) : 0;
    double waiting = waitingMinutes * settings.waitingChargePerMin;

    double total = max(minFare, base + distFare + night + peak + waiting);
    double driverBase = base * 0.85;
    double driverDist = distanceKm * drivRate;
    double driverWait = waiting * 0.85;
    double driverTotal = max(minFare * 0.8, driverBase + driverDist + driverWait);
    double commission = max(0, total - driverTotal);

    return FareBreakdown(
      baseFare: base,
      distanceFare: distFare,
      nightCharge: night,
      peakCharge: peak,
      waitingCharge: waiting,
      totalCustomerFare: total.roundToDouble(),
      driverEarnings: driverTotal.roundToDouble(),
      adminCommission: commission.roundToDouble(),
    );
  }
}
