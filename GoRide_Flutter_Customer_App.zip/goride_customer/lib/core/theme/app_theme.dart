import 'package:flutter/material.dart';

class AppColors {
  static const Color orangePrimary = Color(0xFFFF7A00);
  static const Color orangeLight = Color(0xFFFF9E40);
  static const Color orangeDark = Color(0xFFCC6200);
  static const Color black = Color(0xFF000000);
  static const Color darkCard = Color(0xFF141414);
  static const Color darkBorder = Color(0xFF262626);
  static const Color white = Color(0xFFFFFFFF);
  static const Color greyText = Color(0xFF9E9E9E);
  static const Color greenSuccess = Color(0xFF10B981);
  static const Color redDanger = Color(0xFFEF4444);
}

class AppTheme {
  static final ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.black,
    primaryColor: AppColors.orangePrimary,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.orangePrimary,
      secondary: AppColors.orangeLight,
      surface: AppColors.darkCard,
      onPrimary: AppColors.white,
      onSurface: AppColors.white,
    ),
  );

  static final ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: AppColors.white,
    primaryColor: AppColors.orangePrimary,
    colorScheme: const ColorScheme.light(
      primary: AppColors.orangePrimary,
      surface: Color(0xFFF8F8F8),
      onPrimary: AppColors.white,
      onSurface: AppColors.black,
    ),
  );
}
